/* -----  RSTInstDel.h  ----- */
#ifndef __RSTInstDel_h
#define __RSTInstDel_h


#include "RStarTree.h"


/* declarations */

void Insert(RSTREE R, refentry newentry, int depth);
void DeleteOneRec(RSTREE R);


#endif /* !__RSTInstDel_h */
