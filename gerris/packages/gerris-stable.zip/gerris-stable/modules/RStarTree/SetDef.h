/* -----  SetDef.h  ----- */
#ifndef __SetDef_h
#define __SetDef_h


typedef struct BinTree {
                       int value;
                       struct BinTree *lson;
                       struct BinTree *rson;
                       } SetRec;


#endif /* !__SetDef_h */

